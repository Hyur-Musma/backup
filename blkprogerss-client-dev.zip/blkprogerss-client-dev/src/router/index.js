import { setupLayouts } from 'virtual:generated-layouts'
import { createRouter, createWebHashHistory  } from 'vue-router'
import { useLogsStore } from '@hiway/stores/logs'
import { atuhCheck } from './utils'
import axios from '@axios'

import routes from '~pages'
import { getToken, removeToken, getIsBeforeRemoveToken, removeIsBeforeRemoveToken } from '@hiway/utils/token'
import EventHandler from '@hiway/utils/eventHandler'
import Sso from '../components/Sso.vue'

let isMfeLoaded = false

const router = createRouter({
  history: createWebHashHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      redirect: to => {        
        if (getToken()) return { name: 'index' }
        
        return { name: 'login', query: to.query }
      },
    },
    {
      path: '/sso',
      name: 'sso',
      component: Sso,
      meta: {
        layout: 'blank',
        noAuth: true,
      },
    },
    ...setupLayouts(routes),
  ],
})

// eslint-disable-next-line sonarjs/cognitive-complexity
router.beforeEach((to, from, next) => {  
  if(isMfeLoaded) {
    atuhCheck(to, from, next)  
  } else {    
    EventHandler.once(() => {            
      isMfeLoaded = true
      next(to.path)      
    }, 'mfeLoaded')
  }
})

router.afterEach((to, from) => {  
  const logStore = useLogsStore()

  logStore.setCurrentRoute(to)  
})
// 2023.00.24 추가
const serverType = async() => {
  const loc = document.location
  // return await axios.get(document.location).then(response => response.headers)
  return await axios.get(loc.origin + '/index.html').then(response => response.headers)
}

serverType().then(res => {
  if (res.server === 'Apache' || res.server === undefined) {
    console.log('internal')
    const remoteCall = () => import('remote_app/managerList')
    remoteCall().then(res => {
      [...setupLayouts(res.default)].forEach(mfeRoute => {
        router.addRoute(mfeRoute)    
      })  
    }).catch(() => {
      console.error('Micro Frontend Error: 관리 페이지를 로드하는데 문제가 있습니다. HDxBuilder Web 운영팀에 문의하세요.')
    }).finally(() => {  
      // EventHandler.emit('mfeLoaded')
    })
  }
}).catch((error) => {
}).finally(() => {
  EventHandler.emit('mfeLoaded')
	console.log('mfeLoaded')
}) 

// router.addRoute(...setupLayouts([{}]))


// Docs: https://router.vuejs.org/guide/advanced/navigation-guards.html#global-before-guards
export default router
