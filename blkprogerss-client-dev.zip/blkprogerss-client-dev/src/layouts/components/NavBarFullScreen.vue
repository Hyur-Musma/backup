<script setup>
import FullScreen from '@/@core/components/FullScreen.vue'

</script>

<template>  
  <FullScreen />
</template>   
