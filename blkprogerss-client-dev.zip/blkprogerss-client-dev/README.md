# preset
* 현대 중공업 내부 프로젝트 개발을 위한 UI-Framework Set

## 적용되는 기본 환경
* Vue Framework: `vite`, `vue3`, `pinia`, `vue-router`
* i18n: vue-i18n
* Style: SASS, SCSS, vuetify
* Rest Communication: Axios
* Chart: highchart, echart
* Grid: tuigrid, tabulator
* 주요 라이브러리 추가 예정

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
