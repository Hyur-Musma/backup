package com.hshi.sample.svc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hshi.sample.dao.StockDao;
import com.hshi.sample.vo.StockVO;

@Service
public class StockService {
	
	@Autowired
	private StockDao stockDao;
	
	public List<StockVO> getStock() {
		return stockDao.getStock();
	}
}
