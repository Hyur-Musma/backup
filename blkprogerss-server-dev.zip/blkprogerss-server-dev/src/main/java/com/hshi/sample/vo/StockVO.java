package com.hshi.sample.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockVO {
	private String lot;
	private String sndstg;
	private String ship;
	private int qty;
	private int weight;
}
