package com.hshi.sample.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hhi.hiway.core.dto.res.ComResponseDto;
import com.hhi.hiway.core.util.ResponseComUtil;
import com.hshi.sample.svc.StockService;

@RestController
@RequestMapping("/stock")
public class StockController {
	
	@Autowired
	private StockService stockService;
	
	@Autowired
	private ResponseComUtil responseComUtil;
	
	
	@GetMapping
	public ComResponseDto<?> getStock() {
		return responseComUtil.setResponse200ok(stockService.getStock());
	}

}
