package com.hshi.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.hshi.sample.vo.StockVO;

@Mapper
public interface StockDao {
	List<StockVO> getStock();
}
