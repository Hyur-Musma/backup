package com.hshi;

import org.jasypt.encryption.StringEncryptor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Profile({"dev","prod","local"})
@RequiredArgsConstructor
public class Runner implements ApplicationRunner {

    private final StringEncryptor stringEncryptor;

    @Override
    public void run(ApplicationArguments args) throws Exception {
//        System.out.println("=============================================================");
//        String encrypt = stringEncryptor.encrypt("MzDh~^86");
//        System.out.println(encrypt);
//        System.out.println(stringEncryptor.decrypt("l5PqW6Mcd45nD5TzgF5HLvxRwYC92mAJ"));
//        System.out.println("=============================================================");
    }
}
