package com.hshi.hiway.service.labal.svc;

import com.hhi.hiway.core.dto.common.ResultDescDto;
import com.hhi.hiway.core.dto.res.ComResponseDto;
import com.hhi.hiway.core.exception.BizException;

public interface LabalSvc {

	public ComResponseDto<ResultDescDto> getLabel() throws BizException;
}
