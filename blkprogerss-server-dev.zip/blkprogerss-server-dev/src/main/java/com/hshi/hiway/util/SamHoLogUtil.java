package com.hshi.hiway.util;

import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hhi.hiway.core.dto.member.HiwayMember;
import com.hhi.hiway.core.util.HiwayMemberUtil;

@Slf4j
@Component
public class SamHoLogUtil {
	
	private static String logurl;
	
	@Value("${samho.logurl:'http://172.17.10.68:49003/hiway/applog'}")
	public void setLogUrl(String logurl) {
		SamHoLogUtil.logurl = logurl;
	}
	
    private static HttpHeaders getHeaderInfo() {
    	HttpHeaders headers = new HttpHeaders();
    	
    	headers.setContentType(MediaType.APPLICATION_JSON);
    	headers.add("X-APIVERSION", "2.0.0");
    	
        return headers;
    }
    
    /*
     전송데이터 : {
      (*)app_id: ‘’,
      (*)pc_mobile_type: ‘’,
      event_type: ‘’,
      (*)event_id: ‘’,
      menu_id: ‘’,
      message: ‘’,
      (*)user_id: ‘’
     }
     pc_mobile_type: pc(P)/mobile(M)/smartone(S)
     event_type : 실행(PR)/오류(PE)/정보(PI)
     event_id: 조회(PS)/등록(PI)/수정(PU)/삭제(PD)/출력(AP)/다운로드(AD)/체크(AC)/로그인(AL)/기타(AE)
     */
    @SuppressWarnings({"unchecked" })
    public static HashMap<String, Object> saveLog(HttpServletRequest request, String dataString) {
    	ObjectMapper mapper = new ObjectMapper();
    	
    	HashMap<String, Object> map = new HashMap<>();
		try {
			map = mapper.readValue(dataString, HashMap.class);
		} catch (IOException e) {}
		
		return SamHoLogUtil.saveLog(request, map);
    }
    
    @SuppressWarnings("rawtypes")
    public static HashMap<String, Object> saveLog(HttpServletRequest request, HashMap<String, Object> dataMap) {
		// TODO Auto-generated method stub
    	HashMap<String, Object> result = new HashMap<String, Object>();
    	
    	// 사용자정보
    	HiwayMember userInfo = new HiwayMemberUtil().getHiwayMember();
    	if (userInfo == null) {
    		result.put("statusCode", "900");
            result.put("statusText", "사용자 정보 없음");
            
            return result;
    	}
    	if (!dataMap.containsKey("user_id")) {
    		dataMap.put("user_id", userInfo.getUser_id());
    	}
    	// 필수값 체크
    	if (!dataMap.containsKey("event_type") || !dataMap.containsKey("event_id") || !dataMap.containsKey("menu_id")) {
    		result.put("statusCode", "901");
            result.put("statusText", "필수 데이터 오류");
            
            return result;
    	}
    	
    	HttpServletRequest httpRequest = (HttpServletRequest) request;
    	
    	Map<String, String> headerMap = Collections.list(httpRequest.getHeaderNames())
    		    .stream()
    		    .collect(Collectors.toMap(h -> h, httpRequest::getHeader));
    	// APP 정보
		if (!headerMap.containsKey("app_id")) dataMap.put("app_id", headerMap.get("x-app"));
    	// PC/MOBILE 구분
    	if (!dataMap.containsKey("pc_mobile_type")) {
    		dataMap.put("pc_mobile_type", "P");
    		if (headerMap.containsKey("x-channel")) {
        		String channel = headerMap.get("x-channel");
        		if (channel.contains("Mobile")) {
        			dataMap.put("pc_mobile_type", "M");
        		}
        	}
    	}
    	
    	HttpHeaders headers = SamHoLogUtil.getHeaderInfo();
		
		HttpEntity<HashMap<String, Object>> requestEntity = new HttpEntity<>(dataMap, headers);
		log.debug("edge send info {}", requestEntity);
		
		ResponseEntity<Map> responseMap = null;
		try {
			HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
	        factory.setConnectTimeout(5000); //타임아웃 설정 5초
	        factory.setReadTimeout(5000);//타임아웃 설정 5초
	        RestTemplate restTemplate = new RestTemplate(factory);
			
			responseMap = restTemplate.exchange(logurl, HttpMethod.POST, requestEntity, Map.class);  // 전송
			if (responseMap.getStatusCode() == HttpStatus.OK || responseMap.getStatusCode() == HttpStatus.CREATED || responseMap.getStatusCode() == HttpStatus.ACCEPTED) {
				result.put("statusCode", responseMap.getStatusCodeValue());
	            result.put("statusText", responseMap.getStatusCode());
			}
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			log.error("SamHoLogUtil.postSend Error : {}", e);
            result.put("statusCode", e.getRawStatusCode());
            result.put("statusText", e.getStatusText());
 
        } catch (Exception e) {
        	log.error("SamHoLogUtil.postSend Error : {}", e);
        	result.put("statusCode", responseMap.getBody().get("status"));
            result.put("statusText", responseMap.getBody().get("desc"));
        }
		
		return result;
	}
}
