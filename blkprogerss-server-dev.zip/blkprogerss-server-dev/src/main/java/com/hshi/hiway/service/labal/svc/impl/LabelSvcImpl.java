package com.hshi.hiway.service.labal.svc.impl;

import com.hhi.hiway.core.dto.common.ResultDescDto;
import com.hhi.hiway.core.dto.res.ComResponseDto;
import com.hhi.hiway.core.exception.BizException;
import com.hhi.hiway.core.message.MultiLabalConfig;
import com.hhi.hiway.core.util.ResponseComUtil;
import com.hshi.hiway.service.labal.svc.LabalSvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class LabelSvcImpl implements LabalSvc {

	@Autowired
	private MultiLabalConfig multiLabalConfig;

	@Autowired
	private ResponseComUtil responseComUtil;

	@SuppressWarnings("rawtypes")
	private ComResponseDto comResponseDto;
	private ResultDescDto resultDto;

	public void initLabel() {
		comResponseDto = new ComResponseDto<Object>();
		resultDto = new ResultDescDto();
	}



	@SuppressWarnings("unchecked")
	@Override
	public ComResponseDto<ResultDescDto> getLabel() throws BizException {
		initLabel();

		return  (ComResponseDto<ResultDescDto>) responseComUtil.setResponse200ok(multiLabalConfig.getLabelInfo());
	}

}
