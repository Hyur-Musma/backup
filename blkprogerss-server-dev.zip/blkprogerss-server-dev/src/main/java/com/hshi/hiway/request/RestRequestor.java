package com.hshi.hiway.request;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.hhi.hiway.core.callback.ApiHttpRequestCallback;
import com.hhi.hiway.core.callback.ApiHttpResponseCallback;
import com.hhi.hiway.core.component.ReqContextComponent;
import com.hhi.hiway.core.constant.ComConstant;
import com.hhi.hiway.core.dto.common.CallHistoryInfoDto;
import com.hhi.hiway.core.dto.common.ResultDescDto;
import com.hhi.hiway.core.dto.res.ComResponseDto;
import com.hhi.hiway.core.exception.BizException;
import com.hhi.hiway.core.rest.HttpBaseRequestor;
import com.hhi.hiway.core.util.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;

import java.io.FileNotFoundException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.Iterator;
import java.util.Map;

@Component
public class RestRequestor extends HttpBaseRequestor {

	public <T> ComResponseDto<T> RestApiCall(String url, HttpMethod method, HttpEntity<?> requestEntity,
                                             Class<T> paramterType) {
		CallHistoryInfoDto RESTCallInfoDto = new CallHistoryInfoDto(ComConstant.REST_CALL_SAS_HISTORY_TYPE);
		String reqDatetime = DateUtils.timeStamp(ComConstant.CALL_LOG_DATE_FORMAT);
		RESTCallInfoDto.setReqDatetime(reqDatetime);
		ComResponseDto<T> resultDto = new ComResponseDto<T>();
		ApiHttpRequestCallback requestCallback = new ApiHttpRequestCallback(restTemplate, requestEntity);
		ApiHttpResponseCallback<JsonNode> responseExtractor = new ApiHttpResponseCallback<JsonNode>(objectMapper,
				RESTCallInfoDto, JsonNode.class);
		Integer httpStatus = null;
		String responseMessage = null;

		try {
			RESTCallInfoDto.setUrl(url);
			RESTCallInfoDto.setRequestBody(requestEntity.getBody());
			RESTCallInfoDto.setRequestHeaders(requestEntity.getHeaders().toSingleValueMap());

			JsonNode parameter = restTemplate.execute(url, method, requestCallback, responseExtractor);

			T param = objectMapper.treeToValue(parameter.get("parameter"), paramterType);
			resultDto.setData(param);

			httpStatus = responseExtractor.getHttpStatus();
			responseMessage = responseExtractor.getResponseMessage();
			String responseBodyString = responseExtractor.getResponseBody();

			ResultDescDto resultDescDto = new ResultDescDto();

			if (httpStatus == 200) {
				setResultDescDto(resultDescDto, "200", responseMessage, 200, "");
			} else {
				if (!StringUtils.isEmpty(responseBodyString)) {
					JsonNode report = resultDto.getReport();
					if (report != null) {
						String desc = responseMessage;
						String code = "52000600";
						JsonNode reason = report.get("reason");
						if (reason != null) {
							JsonNode msg = reason.get("errMsg");
							if (msg != null) {
								desc = msg.asText();
							}
							JsonNode jsonCode = reason.get("code");
							if (jsonCode != null) {
								code = jsonCode.asText();
							}
						}
						setResultDescDto(resultDescDto, code, desc, httpStatus, "REST-" + httpStatus);
					} else {
						if (resultDto.getReason() == null) {
							setResultDescDto(resultDescDto, "52000600", responseMessage, httpStatus,
									"REST-" + httpStatus);
						} else {
							String code = "52000600";
							if (httpStatus == 800) {
								code = "40000800";
							} else if (httpStatus == 801) {
								code = "40000801";
							}
							JsonNode reason = resultDto.getReason();
							setResultDescDto(resultDescDto, code, reason.asText(), httpStatus, "REST-" + httpStatus);
						}
					}
					throw new BizException(resultDescDto);
				} else {
					throw new BizException("52000600", "REST error", "REST-900", "900");
				}
			}
			resultDto.setResult(resultDescDto);
		} catch (RestClientException e) {
			Throwable cause = e.getRootCause();
			if (cause instanceof SocketTimeoutException) {
				throw new BizException(cause, "52000620", "Read timed out", "REST-TIMEOUT", "598");
			} else if (cause instanceof ConnectException) {
				throw new BizException(cause, "52000620", "Connection timed out", "REST-TIMEOUT", "598");
			} else if (cause instanceof FileNotFoundException) {
				throw new BizException(cause, "52000620", "file not found", "REST-TIMEOUT", "598");
			} else {
				throw new BizException(cause, "52000620", "PAS REQUEST ERROR", "REST-REQ-ERR", "598");
			}
		} catch (JsonProcessingException e) {
			throw new BizException(e, "org.springframework.http.converter.HttpMessageNotReadableException");
		} finally {
		}
		return resultDto;
	}

	public HttpHeaders getDefaultRESTHeaderInfo(String headerList) {
		String[] defaultHeaders = headerList.split(",");
		Map<String, String> requestHeaders = ReqContextComponent.getComInfoDto().getHeader();
		HttpHeaders headers = new HttpHeaders();

		Iterator<String> keys = requestHeaders.keySet().iterator();
		while (keys.hasNext()) {
			String key = keys.next();
			String value = requestHeaders.get(key);
			key = key.toLowerCase();

			for (int i = 0; i < defaultHeaders.length; i++) {
				String tempDefaultheaderKey = defaultHeaders[i].toLowerCase();

				if (tempDefaultheaderKey.equals(key)) {
					headers.add(key, value);
					break;
				}
			}
		}
		return headers;
	}

}
