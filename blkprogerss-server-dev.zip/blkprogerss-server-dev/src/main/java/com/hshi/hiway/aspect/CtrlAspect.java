package com.hshi.hiway.aspect;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hhi.hiway.core.component.ReqContextComponent;
import com.hhi.hiway.core.constant.ComConstant;
import com.hhi.hiway.core.constant.TokenConstant;
import com.hhi.hiway.core.dto.common.ComInfoDto;
import com.hhi.hiway.core.dto.req.ComRequestDto;
import com.hhi.hiway.core.dto.res.ComResponseDto;
import com.hhi.hiway.core.exception.BizException;
import com.hhi.hiway.core.log.config.OmsConfig;
import com.hhi.hiway.core.mapper.TargetMapper;
import com.hhi.hiway.core.parser.RequestParser;
import com.hhi.hiway.core.util.DateUtils;
import com.hhi.hiway.core.util.HttpUtils;
import com.hhi.hiway.core.util.RequestUtil;
import com.hhi.hiway.core.validation.ValidationComponent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;

@Slf4j
@Aspect
@Component
public class CtrlAspect {
	@Autowired
	private ObjectMapper objectMapper = null;

	@Autowired
	private ValidationComponent validate = null;

	@Autowired
	private RequestParser requestParser = null;

	@Autowired
	private TargetMapper targetMapper = null;

	@Autowired
	private OmsConfig omsConfig;

	@Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
//	@Pointcut("@annotation(org.springframework.stereotype.Controller) || @annotation(org.springframework.web.bind.annotation.RestController)")
	void CtrlPointCut() {
	}

	@SuppressWarnings("null")
	@Around("CtrlPointCut()")
	public <T> Object Before(ProceedingJoinPoint joinPoint) throws Throwable {

		log.debug(this.getClass().getName() + "CtrlAspect: Before =========================");
		ReqContextComponent.setOmsLog(omsConfig.getOmsBasicData()); // OMS LOG DATA Setting

		Object[] args = joinPoint.getArgs();
		int argsLength = args.length;
		log.debug("=== args.size :: {}", argsLength);

		//if(argsLength == 0) return joinPoint.proceed(args);

		ComInfoDto commonInfo = setValidation();

		boolean listYn = false;

		for(int i=0; i<argsLength; i++) {
			if(args[i] instanceof List) {
				listYn = true;
			}
		}

		// ComRequestDto comRequestDto =
		// objectMapper.readValue(commonInfo.getBodyString(), ComRequestDto.class);
		ComRequestDto comRequestDto = null;
		Object parameterObj = null;
		if (StringUtils.isNotEmpty(commonInfo.getBodyString())) {
			if (!listYn) {
				comRequestDto = objectMapper.readValue(commonInfo.getBodyString(), ComRequestDto.class);
				parameterObj = commonInfo.getBodyString();
			} else {
				comRequestDto = new ComRequestDto();
				parameterObj = objectMapper.readValue(commonInfo.getBodyString(),List.class);
				comRequestDto.setReqParameter(parameterObj);
			}
		} else {
			comRequestDto = new ComRequestDto();
			parameterObj = commonInfo.getBodyString();
		}

		comRequestDto.setReqParameter(parameterObj);
		comRequestDto.setComInfoDto(commonInfo);

		ReqContextComponent.setComInfoDto(commonInfo);
		ReqContextComponent.setComRequestDto(comRequestDto);
		ReqContextComponent.setCurrentLang(commonInfo.getXlang());

		Object[] args1 = new Object[argsLength];
		ObjectMapper mapper = new ObjectMapper();

		for (int i=0;i<argsLength;i++) {
			if (args[i] instanceof HttpServletRequest) {
				args1[i] = args[i];
			} else if (args[i] instanceof ComRequestDto) {
				args1[i] = comRequestDto;
			} else {
				args1[i] = args[i];
			}
		}

		Object returnObject = null;
		try {
			returnObject = joinPoint.proceed(args1);
			if (returnObject instanceof ComResponseDto) {
				ReqContextComponent.setComResponseDto((ComResponseDto<?>) returnObject);
			}

		} catch (Throwable e) {
			throw e;
		}
		return returnObject;
	}

	private ComInfoDto setValidation() throws Exception {

		ServletRequestAttributes currentRequestAttributes = (ServletRequestAttributes) RequestContextHolder
				.currentRequestAttributes();

		HttpServletRequest request = currentRequestAttributes.getRequest();

		// Validation을 하기 위해서 객체에 담은
		String reqDatetime = DateUtils.timeStamp(ComConstant.CALL_LOG_DATE_FORMAT);
		ComInfoDto commonInfo = new ComInfoDto();
		try {
			BufferedReader input = new BufferedReader(new InputStreamReader(request.getInputStream()));
			StringBuilder builder = new StringBuilder();
			String buffer = null;
			while ((buffer = input.readLine()) != null) {
				buffer = buffer.trim();
				builder.append(buffer);
			}
			String requestBody = builder.toString();

			commonInfo.setBodyString(requestBody);
		} catch (IOException e) {
			throw new BizException("org.springframework.http.converter.HttpMessageNotReadableException");
		}
		LinkedHashMap<String, String> tempHeaderInfo = new LinkedHashMap<String, String>();

		Enumeration<String> headerNames = request.getHeaderNames();
		String logKey = "";
		String vname = "";
		while (headerNames.hasMoreElements()) {
			String key = headerNames.nextElement();
			String value = request.getHeader(key);
			tempHeaderInfo.put(key, value);
			if (ComConstant.X_LOG_KEY.equals(key.toUpperCase())) {
//				logKey = value + ":" + DateUtils.timeStamp();
				logKey = value;
			}
			if (ComConstant.THINGS_NAME.equals(key.toUpperCase())) {
				vname = value;
			}
			if (ComConstant.X_LANG_SET.equals(key)) {
				currentRequestAttributes.getRequest().getSession().setAttribute(ComConstant.X_LANG_SET, value);
				log.debug("==== session :: "
						+ currentRequestAttributes.getRequest().getSession().getAttribute(ComConstant.X_LANG_SET));
			}
			if (TokenConstant.APP.equals(key.toUpperCase())) {
				RequestUtil.setAppId(value);
			}
			if (TokenConstant.LANG.equals(key.toUpperCase())) {
				RequestUtil.setLang(value);
			}
			if (TokenConstant.HEADER.toUpperCase().equals(key.toUpperCase())) {
				RequestUtil.setToken(value);
			}
		}

		String requestUri = request.getRequestURI();
		String ip = request.getHeader("X-Forwarded-For");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		ip = request.getHeader("X-FORWARDED-FOR");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}

		//헤더 필수 정보 체크
//		if(!tempHeaderInfo.keySet().contains(TokenConstant.APP.toLowerCase()))
//			throw new BizException("not_a_httpheader", Arrays.asList(TokenConstant.APP));

		commonInfo.setRequestUri(requestUri);
//		String clientIp = request.getRemoteAddr();
		commonInfo.setClientIp(ip);
		commonInfo.setReqDatetime(reqDatetime);
		commonInfo.setLogKey(logKey);
		commonInfo.setVname(vname);
		commonInfo.setHeader(tempHeaderInfo);
		commonInfo.setQueryString(HttpUtils.getQueryString(request));
		commonInfo.setXlang(RequestUtil.getLang());

		RequestUtil.setUserIp(ip);

		requestParser.parse(commonInfo);
		targetMapper.doMap(commonInfo);
		validate.vaildate(commonInfo);

		return commonInfo;
	}
}
