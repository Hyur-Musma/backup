package com.hshi.hiway.service.file.ctl;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hhi.hiway.core.dto.res.ComResponseDto;
import com.hhi.hiway.core.exception.BizException;
import com.hhi.hiway.core.util.FileUtils;
import com.hhi.hiway.core.util.ResponseComUtil;
import com.hshi.hiway.service.file.svc.FTPSvc;
import com.hshi.hiway.service.file.vo.FileVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Api(value = "Controller", tags = "파일 업로드 서비스")
@CrossOrigin(origins = "*")
@RequestMapping(value = "/file", headers="X-APIVERSION=2.0.0")
@RestController
public class FileController {

	@Autowired
	private ResponseComUtil responseComUtil;

	@Autowired
    private FTPSvc ftpSvc;
	
	@ApiOperation(value = "파일 다운로드", notes = "파일 다운로드")
	@ApiResponses({
    	@ApiResponse(code = 200, message = "Successful retrieval of demand", response = ComResponseDto.class)
    })
    @GetMapping(value = "/getDownload", headers = "X-APIVERSION=2.0.0")
    public void getDownload(HttpServletRequest request, HttpServletResponse response, FileVo vo) throws BizException, IOException {
		
		Map<String, String> map = ftpSvc.ftpFileDownload(vo.getFilePath(), vo.getFileName());
		
		if (!map.isEmpty()) {
			File file = new File(map.get("filePath")+File.separator+ map.get("fileName"));
			System.out.println("fil0e :"+file);	
			if (file.exists()) {
				try {
					FileUtils.fileDownload(request, response, map.get("filePath"), map.get("fileName"), map.get("fileName"));	
				} finally {
					// TODO: handle exception
					//if (file.exists()) file.delete();
				}
			}
		}
	}
	
	@ApiOperation(value = "파일 byte 가져오기", notes = "파일 byte 가져오기")
	@ApiResponses({
    	@ApiResponse(code = 200, message = "Successful retrieval of demand", response = ComResponseDto.class)
    })
    @GetMapping("/getbyte")
    public ComResponseDto<?> getByte(HttpServletRequest request, HttpServletResponse response, FileVo vo) throws BizException, IOException {
		return responseComUtil.setResponse200ok(ftpSvc.fileGetByte(vo.getFilePath(), vo.getFileName()));
	}
	
	@ApiOperation(value = "파일 삭제", notes = "파일 삭제")
	@ApiResponses({
    	@ApiResponse(code = 200, message = "Successful retrieval of demand", response = ComResponseDto.class)
    })
    @DeleteMapping()
    public ComResponseDto<?> delete(HttpServletRequest request, HttpServletResponse response, FileVo vo) throws BizException, IOException {
		return responseComUtil.setResponse200ok(ftpSvc.fileDelete(vo.getFilePath(), vo.getFileName()));
	}
	
	@ApiOperation(value = "파일 등록", notes = "파일을 서버에 등록", consumes = "application/x-www-form-urlencoded")
	@ApiResponses({
    	@ApiResponse(code = 200, message = "Successful retrieval of demand", response = ComResponseDto.class)
    })
	@PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ComResponseDto<?> savefile(HttpServletRequest request, HttpServletResponse response, 
    		@ApiParam(name = "file", value = "업로드 대상 파일", required = true) @RequestParam("file") MultipartFile file, 
            @ApiParam(name = "filePath", value = "저장경로") @RequestParam(value = "filePath", required = false) String filePath,
            @ApiParam(name = "fileName", value = "저장파일이름") @RequestParam(value = "fileName", required = false) String fileName
    ) throws BizException, IOException {
		
		FileVo vo = new FileVo();
		vo.setFilePath(filePath);
		vo.setFileName(fileName);
		
		return responseComUtil.setResponse200ok(ftpSvc.fileUpload(request, file, vo));
	}
	/*
	@ApiOperation(value = "멀티 파일 등록", notes = "멀티 파일 등록", consumes = "application/x-www-form-urlencoded")
	@ApiResponses({
    	@ApiResponse(code = 200, message = "Successful retrieval of demand", response = ComResponseDto.class)
    })
	@PostMapping(value = "/files")
    public ComResponseDto<?> savefiles(HttpServletRequest request, HttpServletResponse response, @RequestPart("file") List<MultipartFile> fileList, @RequestPart("fileInfo") List<FileVo> voList) throws BizException, IOException {
		
		fileSvc.fileUploads(request, fileList, voList);
		
		return responseComUtil.setResponse200ok();
	}
	*/
}
