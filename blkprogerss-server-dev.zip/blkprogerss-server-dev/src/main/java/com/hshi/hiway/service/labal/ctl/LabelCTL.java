package com.hshi.hiway.service.labal.ctl;

import com.hhi.hiway.core.dto.common.ResultDescDto;
import com.hhi.hiway.core.dto.res.ComResponseDto;
import com.hshi.hiway.service.labal.svc.LabalSvc;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@RestController
public class LabelCTL {
	@Autowired
	private LabalSvc labalSvc;


	@RequestMapping(value = "/getLabel", method = RequestMethod.POST)
	public ComResponseDto<ResultDescDto> getLabel(HttpServletRequest request) throws Exception {

		log.debug("=== :: getLabel");

		return  labalSvc.getLabel()	;
	}
}
