package com.hshi.hiway.spring;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;
import org.springframework.web.util.UrlPathHelper;


@Configuration
@RequiredArgsConstructor
public class WebConfig implements WebMvcConfigurer {

	private final CommonInterceptor commonInterceptor;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(commonInterceptor)
		.addPathPatterns("/**")
		.excludePathPatterns("/swagger-ui.html")
		.excludePathPatterns("/swagger-resources/**")
		.excludePathPatterns("/swagger-resources")
		.excludePathPatterns("/springfox.js")
		.excludePathPatterns("/webjars/**")
		.excludePathPatterns("/v2/api-docs")
		.excludePathPatterns("/apirepo")
		.excludePathPatterns("/login")
		.excludePathPatterns("/login/sso")
		.excludePathPatterns("/login/users/user_id/*")
		.excludePathPatterns("/login/users/*")
		.excludePathPatterns("/login/auth/phone")
		.excludePathPatterns("/login/auth/mail")
        .excludePathPatterns("/login/auth/confirm")
		.excludePathPatterns("/login/users")
		.excludePathPatterns("/file/*")
				.excludePathPatterns("/file/view/*")
		.excludePathPatterns("/menulangs/*")
		.excludePathPatterns("/members/*")
		.excludePathPatterns("/login/token");
	}

	private final long MAX_AGE_SECS = 3600;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedMethods("HEAD", "OPTIONS", "GET", "POST", "PUT", "PATCH", "DELETE")
                .maxAge(MAX_AGE_SECS);
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("swagger-ui.html")
				.addResourceLocations("classpath:/META-INF/resources/");

		registry.addResourceHandler("/webjars/**")
				.addResourceLocations("classpath:/META-INF/resources/webjars/");

    }

    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        UrlPathHelper urlPathHelper = new UrlPathHelper();
        urlPathHelper.setUrlDecode(false);
        urlPathHelper.setAlwaysUseFullPath(true);
        configurer.setUrlPathHelper(urlPathHelper);
    }

//	@Bean
//	public FilterRegistrationBean<XSSFilter> filterRegistrationBean() {
//		FilterRegistrationBean<XSSFilter> filterFilterRegistrationBean = new FilterRegistrationBean<>();
//		filterFilterRegistrationBean.setFilter(new XSSFilter());
//		return filterFilterRegistrationBean;
//	}
}
