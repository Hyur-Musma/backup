package com.hshi.hiway.spring;

import com.hhi.hiway.core.component.ReqContextComponent;
import com.hhi.hiway.core.constant.ComConstant;
import com.hhi.hiway.core.constant.TokenConstant;
import com.hhi.hiway.core.dto.common.ComInfoDto;
import com.hhi.hiway.core.dto.res.ComResponseDto;
import com.hhi.hiway.core.exception.BizException;
import com.hhi.hiway.core.log.OmsFileWriter;
import com.hhi.hiway.core.util.DateUtils;
import com.hhi.hiway.core.util.HiwayMemberUtil;
import com.hhi.hiway.core.util.LinkedHashMap;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
@Component
@RequiredArgsConstructor
public class CommonInterceptor extends HandlerInterceptorAdapter {

	private final HiwayMemberUtil hiwayMemberUtil;

	private final OmsFileWriter omsFileWriter;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

//		ServletRequestAttributes currentRequestAttributes = (ServletRequestAttributes) RequestContextHolder
//				.currentRequestAttributes();
//		String jsonData = (String) currentRequestAttributes.getRequest().getSession(false).getAttribute(TokenConstant.MEMBER);

		log.debug("================ preHandle ================");
		log.debug("request.getRequestURI() : {}", request.getRequestURI());
		log.debug("X-Auth-Token : {}", request.getHeader(TokenConstant.HEADER));
//		log.debug("request.getSession().getId() : {}", currentRequestAttributes.getRequest().getSession(false).getId());
		log.debug("hiwayMemberUtil.getUserId() : {}", hiwayMemberUtil.getUserId());

		if (StringUtils.isBlank(hiwayMemberUtil.getUserId())) {
			throw new BizException("AccessDenied");
		}

		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		log.info("================ postHandle Method");
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object object,
			Exception exception) throws Exception {
		log.info("================ afterCompletion Method");
		if(exception == null) {
			String resDatetime = DateUtils.timeStamp(ComConstant.CALL_LOG_DATE_FORMAT);
			ComInfoDto commonInfoDto = ReqContextComponent.getComInfoDto();

			if(commonInfoDto == null) commonInfoDto = new ComInfoDto();
			commonInfoDto.setResDatetime(resDatetime);

			ComResponseDto<?> comResponseDto = ReqContextComponent.getComResponseDto();

			if(comResponseDto == null) comResponseDto = new ComResponseDto<Void>();

			LinkedHashMap<String, String> omsLog = ReqContextComponent.getOmsLog();
			if (omsLog.containsKey("USER_ID")) {
				omsLog.put("USER_ID", hiwayMemberUtil.getUserId());
			}

			if (omsFileWriter.isOmsIsAsync()) {
				omsFileWriter.asyncWrite(omsLog, commonInfoDto);
			} else {
				omsFileWriter.write(omsLog, commonInfoDto);
			}
		}
	}

}
