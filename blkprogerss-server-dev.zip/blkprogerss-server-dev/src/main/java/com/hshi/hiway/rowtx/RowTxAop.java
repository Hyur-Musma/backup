package com.hshi.hiway.rowtx;

import com.hhi.hiway.core.transaction.row.*;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Aspect
@Order
@Slf4j
public class RowTxAop {

    @Around("@annotation(com.hhi.hiway.core.transaction.row.RealGridRowTx)")
    public Object AfterService(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {

        Object result = proceedingJoinPoint.proceed();

        RealGridComplexDto realGridComplexDto = (RealGridComplexDto) result;

        RealGridDataList realGridDataList = realGridComplexDto.getRealGridDataList();

        List created = realGridDataList.getCreated();
        int c_success = 0;
        int c_fail = 0;

        if (created != null) {
            for (int i=0; i < created.size(); i++) {
                RealGridCustom realGridCustom = (RealGridCustom) created.get(i);
                if (realGridCustom != null && realGridCustom.getCnt() > 0) {
                    realGridCustom.setRet_code("Y");
                    realGridCustom.setRet_msg("등록 성공");
                    c_success++;

                } else {
                    realGridCustom.setRet_code("N");
                    realGridCustom.setRet_msg("등록 실패");
                    c_fail++;
                }
            }
        }

        List updated = realGridDataList.getUpdated();
        int u_success = 0;
        int u_fail = 0;

        if (updated != null) {
            for (int i=0; i < updated.size(); i++) {
                RealGridCustom realGridCustom = (RealGridCustom) updated.get(i);
                if (realGridCustom != null && realGridCustom.getCnt() > 0) {
                    realGridCustom.setRet_code("Y");
                    realGridCustom.setRet_msg("수정 성공");
                    u_success++;

                } else {
                    realGridCustom.setRet_code("N");
                    realGridCustom.setRet_msg("수정 실패");
                    u_fail++;
                }
            }
        }

        List deleted = realGridDataList.getDeleted();
        int d_success = 0;
        int d_fail = 0;

        if (deleted != null) {
            for (int i=0; i < deleted.size(); i++) {
                RealGridCustom realGridCustom = (RealGridCustom) deleted.get(i);
                if (realGridCustom != null && realGridCustom.getCnt() > 0) {
                    realGridCustom.setRet_code("Y");
                    realGridCustom.setRet_msg("삭제 성공");
                    d_success++;

                } else {
                    realGridCustom.setRet_code("N");
                    realGridCustom.setRet_msg("삭제 실패");
                    d_fail++;
                }
            }
        }

        RealGridCreateDto realGridCreateDto  = RealGridCreateDto.builder()
                .count(created == null ? 0 : created.size())
                .success(c_success)
                .fail(c_fail)
                .build();

        RealGridUpdateDto realGridUpdateDto = RealGridUpdateDto.builder()
                .count(updated == null ? 0 : updated.size())
                .success(u_success)
                .fail(u_fail)
                .build();

        RealGridDeleteDto realGridDeleteDto = RealGridDeleteDto.builder()
                .count(deleted == null ? 0 : deleted.size())
                .success(d_success)
                .fail(d_fail)
                .build();

        RealGridTotalDto realGridTotalDto = RealGridTotalDto.builder()
                .count((created == null ? 0 : created.size()) + (updated == null ? 0 : updated.size()) + (deleted == null ? 0 : deleted.size()))
                .success(c_success + u_success + d_success)
                .fail(c_fail + u_fail + d_fail)
                .build();

        RealGridResultDto realGridResultDto = new RealGridResultDto();

//        log.info("realGridTotalDto : {}", realGridTotalDto);
//        log.info("realGridCreateDto : {}", realGridCreateDto);
//        log.info("realGridUpdateDto : {}", realGridUpdateDto);
//        log.info("realGridDeleteDto : {}", realGridDeleteDto);

        realGridResultDto.setRowTxTotalDto(realGridTotalDto);
        realGridResultDto.setRowTxCreateDto(realGridCreateDto);
        realGridResultDto.setRowTxUpdateDto(realGridUpdateDto);
        realGridResultDto.setRowTxDeleteDto(realGridDeleteDto);

        realGridComplexDto.setRowTxResultDto(realGridResultDto);

        log.debug("================================");
        log.debug("retVal : {}", realGridComplexDto);
        log.debug("================================");

        return result;
    }
}
