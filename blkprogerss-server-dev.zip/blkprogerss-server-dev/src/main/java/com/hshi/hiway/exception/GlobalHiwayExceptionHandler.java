package com.hshi.hiway.exception;

import com.hhi.hiway.core.component.ReqContextComponent;
import com.hhi.hiway.core.dto.common.ComInfoDto;
import com.hhi.hiway.core.dto.common.ResultBaseDto;
import com.hhi.hiway.core.dto.common.ResultDescDto;
import com.hhi.hiway.core.dto.res.ComResponseDto;
import com.hhi.hiway.core.exception.BizException;
import com.hhi.hiway.core.exception.GlobalBaseExceptionHandler;
import com.hhi.hiway.core.validation.CustomCollectionValidator;
import com.ulisesbocchio.jasyptspringboot.exception.DecryptionException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.UndeclaredThrowableException;

//import com.hhi.hiway.core.exception.GlobalExceptionHandler;

@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
@Order(Ordered.HIGHEST_PRECEDENCE)
public class GlobalHiwayExceptionHandler extends GlobalBaseExceptionHandler {

	private final CustomCollectionValidator validator;

	@InitBinder
	public void initBinder(WebDataBinder webDataBinder) {
		webDataBinder.setValidator(validator);
	}

	@ExceptionHandler(Exception.class)
	public @ResponseBody
    ResultBaseDto handleException(Exception ex, HttpServletRequest req, HttpServletResponse response)
			throws Exception {
		ResultBaseDto result = new ResultBaseDto();
		ResultDescDto resultDesc = null;
		Throwable throwable = null;


		if (ex instanceof UndeclaredThrowableException) {
			UndeclaredThrowableException exception = (UndeclaredThrowableException) ex;
			throwable = exception.getUndeclaredThrowable();
			if (throwable instanceof BizException) {
				BizException bizException = (BizException) throwable;
				String ymlKey = bizException.getYmlKey();
				log.debug("YMLKEY = {} /n", ymlKey);
				resultDesc = getResultDescDto(ymlKey);
			}
		} else if (ex instanceof BizException) {
			BizException bizException = (BizException) ex;
			String ymlKey = bizException.getYmlKey();
			if (StringUtils.isEmpty(ymlKey)) {
				// resultDesc = getResultDescDto("notdefine");
				resultDesc = bizException.getRst();
			} else {
				if (bizException.getArrayReplace() != null) {
					resultDesc = getResultDescDto(ymlKey, bizException.getArrayReplace().toArray());
				} else {
					resultDesc = getResultDescDto(ymlKey);
				}
			}
			throwable = bizException.getThrowable();
		} else if (ex instanceof MethodArgumentNotValidException) {
			BizException bizException = new BizException("org.springframework.web.bind.MethodArgumentNotValidException");
			String ymlKey = bizException.getYmlKey();
			log.debug("YMLKEY = {} /n", ymlKey);
			resultDesc = getResultDescDto(ymlKey);

			MethodArgumentNotValidException methodArgumentNotValidException = (MethodArgumentNotValidException) ex;
			BindingResult bindingResult = methodArgumentNotValidException.getBindingResult();
			FieldError fieldError = bindingResult.getFieldErrors().get(0);
			resultDesc.setDesc(fieldError.getField() + " : " + fieldError.getDefaultMessage());

		} else if (ex instanceof BindException) {
			BizException bizException = new BizException("org.springframework.validation.BindException");
			String ymlKey = bizException.getYmlKey();
			log.debug("YMLKEY = {} /n", ymlKey);
			resultDesc = getResultDescDto(ymlKey);

			BindException bindException = (BindException) ex;
			FieldError fieldError = bindException.getFieldErrors().get(0);
			resultDesc.setDesc(fieldError.getField() + " : " + fieldError.getDefaultMessage());

		} else {
			String errorName = ex.getClass().getName().toString();
			resultDesc = getResultDescDto(errorName);
		}
		result.setResult(resultDesc);
		ComResponseDto<Void> comResponseDto = new ComResponseDto<Void>();
		comResponseDto.setResult(resultDesc);
		comResponseDto.setIsException(true);
		ReqContextComponent.setComResponseDto(comResponseDto);

		// todo 확인 ComInfoDto의 용도는 ? //
		ComInfoDto comInfoDto = ReqContextComponent.getComInfoDto();

		String logKey = "";

		try {
			logKey = ReqContextComponent.getLogKey();
		} catch (Exception e) {
			logKey = "";
		}

		if (throwable != null) {
			log.error("[LOGKEY : {}] [ERROR MESSAGE : {}] [DETAIL ERROR MESSAGE : {}]",
					logKey, ExceptionUtils.getStackTrace(ex),
					ExceptionUtils.getStackTrace(throwable));
			comInfoDto.setErrorMsg(ExceptionUtils.getStackTrace(throwable).toString());
			//resultDesc.setSysMsg(ExceptionUtils.getStackTrace(throwable).toString());
		} else {
			log.error("[LOGKEY : {}] [ERROR MESSAGE : {}]", logKey,
					ExceptionUtils.getStackTrace(ex));
			if (comInfoDto == null) {
				comInfoDto = new ComInfoDto();
			}
			comInfoDto.setErrorMsg(ExceptionUtils.getStackTrace(ex).toString());
			//resultDesc.setSysMsg(ExceptionUtils.getStackTrace(throwable).toString());

		}
		comInfoDto.setIsException(true);
		response.setStatus(Integer.parseInt(resultDesc.getStatus()));

		comInfoDto.setResultDescDto(resultDesc);
		return result;
	}


	@ExceptionHandler(DecryptionException.class)
	public @ResponseBody void handleException01(Exception ex, HttpServletRequest req, HttpServletResponse response)
			throws Exception {
		log.debug("================== error");
	}
}
