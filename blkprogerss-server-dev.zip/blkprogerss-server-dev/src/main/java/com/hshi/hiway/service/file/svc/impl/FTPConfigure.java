package com.hshi.hiway.service.file.svc.impl;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Configuration
@RequiredArgsConstructor
public class FTPConfigure {
	private final Environment environment;

	public FTPEnvironment getFTPConfigure(String prefix) {
		String ftpIp = environment.getProperty(prefix + ".ip", String.class);
		String ftpPort = environment.getProperty(prefix + ".port", String.class);
		String ftpId = environment.getProperty(prefix + ".id", String.class);
		String ftpPassword = environment.getProperty(prefix + ".password", String.class);
		String ftpDefaultPath = environment.getProperty(prefix + ".defaultPath", String.class);
		
		return new FTPEnvironment(ftpIp, ftpPort, ftpId, ftpPassword, ftpDefaultPath);
    }
	
	@Getter
	@Setter
	@RequiredArgsConstructor
	public class FTPEnvironment {
		private String charSet = "euc-kr";
		private final String ftpIp;
		private final String ftpPort;
		private final String ftpId;
		private final String ftpPassword;
		private final String ftpDefaultPath;
	}
}