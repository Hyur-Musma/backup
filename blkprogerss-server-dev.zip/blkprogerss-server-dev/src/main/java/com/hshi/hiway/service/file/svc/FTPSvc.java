package com.hshi.hiway.service.file.svc;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.hshi.hiway.service.file.svc.impl.FTPConfigure.FTPEnvironment;
import com.hshi.hiway.service.file.vo.FileVo;

public interface FTPSvc {
	
	public void setConfigure(FTPEnvironment environment);
	
	public boolean ftpFileExist(String remotePath, String remoteFileName);
	
	public void ftpFileUpload(String localFilePath, String remotePath, String remoteFileName);
	
	public void ftpFileUpload(String localPath, String localFileName, String remotePath, String remoteFileName);
	
	/* Download 결과값
	 * filePath : 로컬경로
	 * fileName : 파일이름
	 */
	public Map<String, String> ftpFileDownload(String remotePath, String remoteFileName);
	
	public byte[] bftpFileDownload(String remotePath, String remoteFileName);
	
	public boolean ftpDelete(String remotePath, String remoteFileName);
	
	/*
	 * Upload 결과값
	 * filePath    : 저장경로
	 * fileOrgName : 원본이름
	 * fileName    : 저장이름
	 * fileSize    : 파일크기
	 */
	public Map<String, String> fileUpload(HttpServletRequest request, MultipartFile multipartFile, FileVo vo);
	
	/*
	 * Upload 결과값 List
	 * filePath    : 저장경로
	 * fileOrgName : 원본이름
	 * fileName    : 저장이름
	 * fileSize    : 파일크기
	 */
	public List<Map<String, String>> fileUploads(HttpServletRequest request, List<MultipartFile> fileList, List<FileVo> voList);
	
	/* 
	 * 파일정보 조회
	 * ext  : 확장자
	 * byte : 파일크기
	 */
	public Map<String, Object> fileGetByte(String remotePath, String remoteFileName);
	
	public boolean fileDelete(String remotePath, String remoteFileName);
}