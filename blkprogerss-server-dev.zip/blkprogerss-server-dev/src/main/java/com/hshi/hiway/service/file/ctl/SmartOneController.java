package com.hshi.hiway.service.file.ctl;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.hshi.hiway.service.file.svc.UploadSvc;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Api(value = "Controller", tags = "smartone 서비스")
@CrossOrigin(origins = "*")
@RequestMapping(value = "/file")
@RestController
public class SmartOneController {

	@Autowired(required=false)
	UploadSvc svc;
	
	@Value("${file.upload-dir:#{systemProperties['user.home'] + '/uploads'}}")
	String uploadDir;
	
	@Value("${ftp.localdelete:true}")
	private boolean ftpLocaldelete;

	private String separator = "/";

	@PostMapping("/upload")
	public Map<String, Object> savefile(MultipartHttpServletRequest request) throws IOException {
		// 업로드 폴더 유무 확인
		File f = new File(uploadDir);
		if (!f.exists()) {
			f.mkdir();
		}

		Map<String, String> param = getQueryParameters(request);

		String message = "success";
		List<Map<String, Object>> fileList = new ArrayList<>();
		try {
			MultiValueMap<String, MultipartFile> attachments = request.getMultiFileMap();

		    attachments.forEach((key, multipartFiles) -> {
		    	multipartFiles.forEach(file -> {
		    		// do your all operations for each file and productDto.
		    		// like productService.saveProductDTO(productDTO);

		    		String originalFilename = "";
		    		if (file.getOriginalFilename().lastIndexOf(separator) > 0) {
		    			originalFilename = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(separator) + 1, file.getOriginalFilename().length());	
		    		} else {
		    			originalFilename = file.getOriginalFilename();
		    		}
		    		String[] split = originalFilename.split("\\.(?=[^\\.]+$)");
		    		Path destination = Paths.get(uploadDir).resolve(originalFilename).normalize().toAbsolutePath();
		    		try {
		    			Map<String, Object> map = new HashMap<>();	
		    			map.put("fileFullPath", destination.toString());
						map.put("fileName", originalFilename);
						map.put("fileExt", split[1]);
						map.put("fileSize", file.getSize());
						fileList.add(map);

						Files.copy(file.getInputStream(), destination);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						log.error(ExceptionUtils.getStackTrace(e));
					}
		    	});
		    });
		} catch (Exception e) {
			// TODO: handle exception
			log.error(ExceptionUtils.getStackTrace(e));
			message = "fail";
		}
		
		// 처리
		Map<String, String> data = new HashMap<>();
		if (svc != null) {
			data = svc.upload(fileList, param);
		}

		// 삭제
		if (ftpLocaldelete) {
			fileList.forEach(map -> {
				String fileFullPath = (String) map.get("fileFullPath");
				File file = new File(fileFullPath);
				if (file.exists()) {
					file.delete();
				}
			});
		}

		Map<String, Object> result = new HashMap<>();
		result.put("message", message);
		result.put("data", data);

		return result;
	}
	
	private Map<String, String> getQueryParameters(HttpServletRequest request) throws UnsupportedEncodingException {
	    Map<String, String> queryParameters = new HashMap<>();
	    String queryString = request.getQueryString();
	    if (StringUtils.isNotEmpty(queryString)) {
	        queryString = URLDecoder.decode(queryString, StandardCharsets.UTF_8.toString());
	        String[] parameters = queryString.split("&");
	        for (String parameter : parameters) {
	            String[] keyValuePair = parameter.split("=");
	            if (keyValuePair.length > 1)
	            	queryParameters.put(keyValuePair[0], keyValuePair[1]);
	            else 
	            	queryParameters.put(keyValuePair[0], "");
	            /*
	            String values = queryParameters.get(keyValuePair[0]);
	            //length is one if no value is available.
	            values = keyValuePair.length == 1 ? ArrayUtils.add(values, "") :
	                    ArrayUtils.addAll(values, keyValuePair[1].split(",")); //handles CSV separated query param values.
	            queryParameters.put(keyValuePair[0], values);
	            */
	        }
	    }

	    return queryParameters;
	}
}