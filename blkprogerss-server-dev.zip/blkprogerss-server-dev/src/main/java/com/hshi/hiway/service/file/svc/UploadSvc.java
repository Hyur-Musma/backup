package com.hshi.hiway.service.file.svc;

import java.util.List;
import java.util.Map;

public interface UploadSvc {
	
	/* *** List<Map<String, Object>> fileList 의 map 항목 ***
	 * fileFullPath : 파일전체경로
	 * fileName : 파일이름
	 * fileExt : 파일확장자
	 * fileSize : 파일사이즈
	 */
	
	/* *** Map<String, String> param ***
	 * url 전송시 query로 전송된 값
	 * 예) /file/upload?subParam=20230611
	 * subParam key로 값을 조회하면 20230611 return
	 */
	
	/* *** return map ***
	 * map의 data key에 값저장 
	 */
	Map<String, String> upload(List<Map<String, Object>> fileList, Map<String, String> param);
}