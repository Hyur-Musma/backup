package com.hshi.hiway.service.file.svc.impl;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hhi.hiway.core.exception.BizException;
import com.hhi.hiway.core.util.FileUtils;
import com.hshi.hiway.service.file.svc.FTPSvc;
import com.hshi.hiway.service.file.svc.impl.FTPConfigure.FTPEnvironment;
import com.hshi.hiway.service.file.vo.FileVo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FTPSvcImpl implements FTPSvc {
	
	private String separator = "/";
	private String systemType = "";
	
	@Value("${file.max-size}")
	private long fileMaxSize;
	
	@Value("${file.upload-dir:#{''}}")
	private String fileUploadDir;
	
	@Value("${file.extensions}")
	private String fileExtensions;
	
	@Value("${ftp.charset:euc-kr}")
	private String charSet;
	
	@Value("${ftp.ip:#{''}}")
	private String ftpIp;
	
	@Value("${ftp.port:#{''}}")
	private String ftpPort;
	
	@Value("${ftp.id:#{''}}")
	private String ftpId;
	
	@Value("${ftp.password:#{''}}")
	private String ftpPassword;
	
	@Value("${ftp.defaultPath:#{''}}")
	private String ftpDefaultPath;
	
	@Value("${ftp.localdelete:true}")
	private boolean ftpLocaldelete;
	
	public void setConfigure(FTPEnvironment environment) {
		this.charSet = environment.getCharSet();
		this.ftpIp = environment.getFtpIp();
		this.ftpPort = environment.getFtpPort();
		this.ftpId = environment.getFtpId();
		this.ftpPassword = environment.getFtpPassword();
		this.ftpDefaultPath = environment.getFtpDefaultPath();
	}
	
	private void r_close(Closeable  ... resources) {
		for (Closeable resource : resources) {
			if (resource != null) {
				try {
					resource.close();
				} catch (Exception ignore) {}
			}
		}
	}
	
	private FTPClient ftpLogin() {
		// 
		FTPClient ftpClient = new FTPClient();
		ftpClient.setControlEncoding(charSet);
		try {
			ftpClient.connect(ftpIp, Integer.parseInt(ftpPort));
			
			int resultCode = ftpClient.getReplyCode();
			
			if (FTPReply.isPositiveCompletion(resultCode)) {
				ftpClient.setSoTimeout(5000);
				boolean isLogin = ftpClient.login(ftpId, ftpPassword);
				if (!isLogin) {
					if (ftpClient.isConnected()) ftpClient.disconnect();
					ftpClient = null;
				} else {
					ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
				}
			} else {
				if (ftpClient.isConnected()) ftpClient.disconnect();
				ftpClient = null;
			}
			
			systemType = ftpClient.getSystemType().toUpperCase();
			if (systemType.contains("WINDOWS")) {
				separator = "\\";
				if (ftpDefaultPath.contains("/")) ftpDefaultPath = ftpDefaultPath.replaceAll("/", "\\\\");
			} else {
				if (ftpDefaultPath.contains("\\")) ftpDefaultPath = ftpDefaultPath.replaceAll("\\\\", "/");
			}
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			log.error(ExceptionUtils.getStackTrace(e));
			
			try {
				if (ftpClient.isConnected()) ftpClient.disconnect();
			} catch (IOException e1) {}
			
			ftpClient = null;
		}
		
		return ftpClient;
	}
	
	private void ftpLogout(FTPClient ftpClient) {
		if (ftpClient != null && ftpClient.isConnected()) {
			try {
				ftpClient.logout();
				ftpClient.disconnect();
			} catch (IOException e) {}
		}
	}
	
	@Override
	public void ftpFileUpload(String localPath, String localFileName, String remotePath, String remoteFileName) {
		if (!localPath.startsWith(File.separator)) {
			localPath = File.separator + localPath;
		}
		if (!localPath.endsWith(File.separator)) {
			localPath = localPath + File.separator;
		}
		
		ftpFileUpload(localPath + localFileName, remotePath, remoteFileName);
	}
	
	@Override
	public void ftpFileUpload(String localFilePath, String remotePath, String remoteFileName) {
		// TODO Auto-generated method stub
		
		FTPClient ftpClient = this.ftpLogin();
		try {
			if (ftpClient != null && ftpClient.isConnected()) {
				
				if (systemType.contains("WINDOWS")) {
					remotePath = remotePath.replaceAll("/", "\\\\");
				} else {
					remotePath = remotePath.replaceAll("\\\\", "/");
				}		
				
				boolean existRoot = ftpClient.changeWorkingDirectory(ftpDefaultPath);
				if(existRoot) {
					
					if (!remotePath.startsWith(separator)) {
						remotePath = separator + remotePath;
					}
					if (!remotePath.endsWith(separator)) {
						remotePath = remotePath + separator;
					}
					//
					boolean existDir = true;

					if (ftpDefaultPath.lastIndexOf(separator) > -1) {
						existDir = ftpClient.changeWorkingDirectory(ftpDefaultPath + remotePath);
					} else {
						existDir = ftpClient.changeWorkingDirectory(ftpDefaultPath + separator + remotePath);
					}
					
					if(!existDir) {
						String[] paths = remotePath.split(separator);
						for(int i = 0 ; i < paths.length; i ++) {
							ftpClient.makeDirectory(paths[i]);
							ftpClient.changeWorkingDirectory(paths[i]);
						}
					}
					
					// File localfile = new File(fileUploadDir + File.separator + fileName);	// File 객체
					File localfile = new File(localFilePath);	// File 객체
					if (localfile.exists()) {
						FileInputStream fileInputStream = null;	// 업로드할 File 생성
						try {
							fileInputStream = new FileInputStream(localfile);
							ftpClient.storeFile(remoteFileName, fileInputStream);
						} finally {
							r_close(fileInputStream);
							if (ftpLocaldelete) localfile.delete();
						}
					}
				} else {
					throw new BizException("파일 혹은 디렉토리가 존재하지 않습니다.");
				}
			}
		} catch(Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		} finally {
			// TODO: handle exception
			this.ftpLogout(ftpClient);
		}
	}
	
	@Override
	public boolean ftpFileExist(String remotePath, String remoteFileName) {
		// TODO Auto-generated method stub
		// FTP 관련 정의
		boolean result = false;
		
		if (remotePath == null) remotePath = "";
		if (remoteFileName == null) remoteFileName = "";

		FTPClient ftpClient = this.ftpLogin();
		try {
			if (ftpClient != null && ftpClient.isConnected()) {
				
				if (systemType.contains("WINDOWS")) {
					remotePath = remotePath.replaceAll("/", "\\\\");
				} else {
					remotePath = remotePath.replaceAll("\\\\", "/");
				}
				
				if (!remotePath.startsWith(separator)) {
					remotePath = separator + remotePath;
				}
				if (!remotePath.endsWith(separator)) {
					remotePath = remotePath + separator;
				}
				
				FTPFile[] remoteFiles = ftpClient.listFiles(ftpDefaultPath + remotePath);
				
				for (FTPFile ftpFile : remoteFiles) {
                    // Check if FTPFile is a regular file
                    if (ftpFile.getType() == FTPFile.FILE_TYPE && ftpFile.getName().equals(remoteFileName)) {
                    	result = true;
                    	break;
                    	// System.out.printf("FTPFile: %s; %s%n", ftpFile.getName(), FileUtils.byteCountToDisplaySize(ftpFile.getSize()));
                    }
                }
			}
		} catch(Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		} finally {
			// TODO: handle exception
			this.ftpLogout(ftpClient);
		}
		
		return result;
	}
	
	@Override
	public Map<String, String> ftpFileDownload(String remotePath, String remoteFileName) {
		// TODO Auto-generated method stub
	
		Map<String, String> resultMap = new HashMap<>();
		
		if (remotePath == null) remotePath = "";
		if (remoteFileName == null) remoteFileName = "";
		
		FTPClient ftpClient = this.ftpLogin();
		try {
			if (ftpClient != null && ftpClient.isConnected()) {
				
				if (systemType.contains("WINDOWS")) {
					remotePath = remotePath.replaceAll("/", "\\\\");
				} else {
					remotePath = remotePath.replaceAll("\\\\", "/");
				}
				
				if (!remotePath.startsWith(separator)) {
					remotePath = separator + remotePath; 
				}
				if (!remotePath.endsWith(separator)) {
					remotePath = remotePath + separator;
				}
				boolean existDir = ftpClient.changeWorkingDirectory(ftpDefaultPath + remotePath);
				if(existDir) {
					InputStream inputStream = null;
					try {
						inputStream = ftpClient.retrieveFileStream(remoteFileName);
						if (inputStream != null && ftpClient.getReplyCode() != 550) { /*550 디렉토리 오류*/
							File localFile = new File(fileUploadDir + separator + remoteFileName);
							// 기존파일존재여부
							if (localFile.exists()) {
								localFile.delete();
							}
							// 디렉토리생성
							Files.createDirectories(Path.of(fileUploadDir));
							// 파일 복사
							Files.copy(inputStream, localFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
							
							resultMap.put("filePath", fileUploadDir);
							resultMap.put("fileName", remoteFileName);
						} else {
							throw new BizException("파일 혹은 디렉토리가 존재하지 않습니다.");
						}								
					} finally {
						r_close(inputStream);
					}
				} else {
					throw new BizException("파일 혹은 디렉토리가 존재하지 않습니다.");
				}
			}
		} catch(Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		} finally {
			// TODO: handle exception
			this.ftpLogout(ftpClient);
		}
		
		return resultMap;
	}
	
	@Override
	public byte[] bftpFileDownload(String remotePath, String remoteFileName) {
		// TODO Auto-generated method stub
	
		byte[] result = new byte[0];
		if (remotePath == null) remotePath = "";
		if (remoteFileName == null) remoteFileName = "";
		
		FTPClient ftpClient = this.ftpLogin();
		try {
			if (ftpClient != null && ftpClient.isConnected()) {
				
				if (systemType.contains("WINDOWS")) {
					remotePath = remotePath.replaceAll("/", "\\\\");
				} else {
					remotePath = remotePath.replaceAll("\\\\", "/");
				}

				if (!remotePath.startsWith(separator)) {
					remotePath = separator + remotePath; 
				}
				if (!remotePath.endsWith(separator)) {
					remotePath = remotePath + separator;
					
				}
				boolean existDir = ftpClient.changeWorkingDirectory(ftpDefaultPath + remotePath);
				if(existDir) {
					InputStream inputStream = null;
					try {
						inputStream = ftpClient.retrieveFileStream(remoteFileName);
						if (inputStream != null && ftpClient.getReplyCode() != 550) { /*550 디렉토리 오류*/
							// 
							result = inputStream.readAllBytes();
						} else {
							throw new BizException("파일 혹은 디렉토리가 존재하지 않습니다.");
						}								
					} finally {
						r_close(inputStream);
					}
				} else {
					throw new BizException("파일 혹은 디렉토리가 존재하지 않습니다.");
				}
			}
		} catch(Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		} finally {
			// TODO: handle exception
			this.ftpLogout(ftpClient);
		}
		
		return result;
	}
	
	@Override
	public boolean ftpDelete(String remotePath, String remoteFileName) {
		// TODO Auto-generated method stub
		// FTP 관련 정의
		boolean result = false;
		
		if (remotePath == null) remotePath = "";
		if (remoteFileName == null) remoteFileName = "";

		FTPClient ftpClient = this.ftpLogin();
		try {
			if (ftpClient != null && ftpClient.isConnected()) {
				
				if (systemType.contains("WINDOWS")) {
					remotePath = remotePath.replaceAll("/", "\\\\");
				} else {
					remotePath = remotePath.replaceAll("\\\\", "/");
				}
				
				if (!remotePath.startsWith(separator)) {
					remotePath = separator + remotePath;
				}
				if (!remotePath.endsWith(separator)) {
					remotePath = remotePath + separator;
				}
			
				FTPFile[] remoteFiles = ftpClient.listFiles(ftpDefaultPath + remotePath);
			    if (remoteFiles.length > 0) {
			    	result = ftpClient.deleteFile(ftpDefaultPath + remotePath + remoteFileName);        	
			    } else {
			    	result = ftpClient.removeDirectory(ftpDefaultPath + remotePath);
			    }
			}
		} catch(Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		} finally {
			// TODO: handle exception
			this.ftpLogout(ftpClient);
		}

		return result;		
	}

	@Override
	public Map<String, String> fileUpload(HttpServletRequest request, MultipartFile multipartFile, FileVo vo) {
		// TODO Auto-generated method stub
		
		Map<String, String> resultMap = new HashMap<String, String>();
		
		if (vo.getFilePath() == null) vo.setFilePath("");
		if (vo.getFileName() == null || "".equals(vo.getFileName())) {
			vo.setFileName(multipartFile.getOriginalFilename());
		}
		
		// 파일이 존재하면
		if (ftpFileExist(vo.getFilePath(), vo.getFileName())) {
			// all possible unicode characters
			String dateTime = new SimpleDateFormat("yyyyMMddHHmmssSSSS").format(new Date());
			String[] filename = vo.getFileName().split("\\.");
			
			if (filename.length > 1) {
				vo.setFileName(filename[0] + "_" + dateTime + "." + filename[1]);	
			} else {
				vo.setFileName(vo.getFileName() + "_" + dateTime);
			}
		}
		
		/*
		fileInfo[0] : 저장위치
		fileInfo[1] : 원본이름
		fileInfo[2] : 저장이름
		fileInfo[3] : 파일크기
		*/
		FileUtils.setFileExtensions(Arrays.asList(fileExtensions));
		String[] fileInfo = FileUtils.uploadToOneFile(request, fileUploadDir, multipartFile, vo.getFileName(), fileMaxSize);
		
		String fileFullPath = fileInfo[0] + separator + fileInfo[1];
		try {
			this.ftpFileUpload(fileFullPath, vo.getFilePath(), vo.getFileName());
			resultMap.put("filePath", fileInfo[0]);
			resultMap.put("fileOrgName", fileInfo[1]);
			resultMap.put("fileSaveName", fileInfo[2]);
			resultMap.put("fileSize", fileInfo[3]);
		} finally {
			File file = new File(fileFullPath);
			if (file.exists() && ftpLocaldelete) file.delete(); 
		}
		
		return resultMap;
	}

	@Override
	public Map<String, Object> fileGetByte(String remotePath, String remoteFileName) {
		// TODO Auto-generated method stub
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		Map<String, String> map = this.ftpFileDownload(remotePath, remoteFileName);
		
		String localPath = "";
		String localName = "";
		if (map.containsKey("filePath") && map.containsKey("fileName")) {
			localPath = map.get("filePath");
			localName = map.get("fileName");
			if (!localPath.startsWith(File.separator)) {
				localPath = File.separator + localPath;
			}
			if (!localPath.endsWith(File.separator)) {
				localPath = localPath + File.separator;
			}	
		}
		
		File file = new File(localPath + localName);
		if (file.exists()) {
			String ext = "png";
			String[] split = localName.split(".");
	        if (split.length > 1) ext = split[1];
			
			InputStream inputStream = null;
			try {
				inputStream = new FileInputStream(file);
	        	if (inputStream != null) {
	        		resultMap.put("ext", ext);
	        		resultMap.put("byte", IOUtils.toByteArray(inputStream));
	        	}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				log.error(ExceptionUtils.getStackTrace(e));
			} finally {
				if (ftpLocaldelete) file.delete();
				if (inputStream != null)
					try {
						inputStream.close();
					} catch (IOException e) {}
			}
		}
		
		return resultMap;
	}

	@Override
	public List<Map<String, String>> fileUploads(HttpServletRequest request, List<MultipartFile> fileList, List<FileVo> voList) {
		// TODO Auto-generated method stub
		List<Map<String, String>> resultList = new ArrayList<>();
		
		int[] counter = new int[1];
		fileList.forEach(file -> {
			FileVo vo = voList.get(counter[0]++);
			Map<String, String> map = this.fileUpload(request, file, vo);
			resultList.add(map); 
		});
		
		return resultList;
	}

	@Override
	public boolean fileDelete(String remotePath, String remoteFileName) {
		// TODO Auto-generated method stub
		// FTP 관련 정의
		return this.ftpDelete(remotePath, remoteFileName);
	}
}